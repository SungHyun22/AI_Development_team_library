class InsideMethod extends React.Component {
  render() {
    return styled(Component)`
      line-height: 21px;
    `;
  }
}
