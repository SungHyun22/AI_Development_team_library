const StyledBroken = styled.div<{
    multipleLines: boolean;
}>`
    background: red;
`;
