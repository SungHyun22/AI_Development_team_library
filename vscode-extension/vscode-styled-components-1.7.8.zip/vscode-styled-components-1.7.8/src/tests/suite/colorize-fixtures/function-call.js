const Component = styled(getComponent(props))`
  max-width: 100%;
`;
