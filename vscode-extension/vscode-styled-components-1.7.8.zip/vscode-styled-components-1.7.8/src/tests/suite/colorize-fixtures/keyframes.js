const rotate360 = keyframes`
    from {
        transform: rotate(0deg);
    }
    to {
        transform: rotate(1turn);
    }
`;

const something = keyframes`
    68%, 72% { left: 50px; }
`;
