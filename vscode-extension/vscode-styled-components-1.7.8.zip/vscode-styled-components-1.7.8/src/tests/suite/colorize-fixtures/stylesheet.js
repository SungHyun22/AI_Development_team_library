const styles = stylesheet`
  html {
    color: 'red';
  }
`;
