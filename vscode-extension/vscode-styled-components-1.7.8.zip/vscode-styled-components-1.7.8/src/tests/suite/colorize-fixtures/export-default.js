export default styled(ExportComponent)`
  max-width: 100%;
`;
