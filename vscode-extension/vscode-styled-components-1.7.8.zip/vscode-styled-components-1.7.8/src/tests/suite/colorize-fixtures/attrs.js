const Link = styled.a.attrs({
  target: "_blank",
})`
  color: red;
`;
