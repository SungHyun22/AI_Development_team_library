const ObjectLiteral = {
  styles: styled`
        height: 12px;
        color: #000000;
        font: ${props => "lol"};
        ${props => "padding: 5px"}
        ${props => "border"}: 1px solid #000000;
    `
};
