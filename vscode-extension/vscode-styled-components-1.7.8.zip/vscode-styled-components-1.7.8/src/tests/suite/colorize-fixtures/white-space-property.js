export const WhiteSpaceProperty = styled.div`
  white-space: nowrap;
`;
