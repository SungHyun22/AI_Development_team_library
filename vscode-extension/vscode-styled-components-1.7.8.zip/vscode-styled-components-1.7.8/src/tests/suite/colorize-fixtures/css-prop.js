<div
  css={`
    background: papayawhip;
    color: ${props => props.theme.colors.text};
  `}
/>;
