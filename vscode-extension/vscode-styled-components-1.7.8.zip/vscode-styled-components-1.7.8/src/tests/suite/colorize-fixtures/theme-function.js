const StyledDiv = styled.div(({theme}) => `
    color: ${theme.primary.main};
    height: 12px;
`)
