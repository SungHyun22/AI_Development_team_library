function insideFunction() {
  return styled.div`
    height: 15px;
  `;
}
