const Link = styled.a.withConfig({
  shouldForwardProp: () => false
})`
  color: red;
`;
