const Link = styled.a.attrs<Props>({
    target: "_blank"
  })<Props>`
  color: red;
  `;
