const StringTagname = styled("div")`
  color: #ff0000;
`;
