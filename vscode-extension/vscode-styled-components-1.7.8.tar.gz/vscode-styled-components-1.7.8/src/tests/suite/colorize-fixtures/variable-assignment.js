let variableAssignment;

variableAssignment = css`
  height: 1px;
`(
  /* expression */
  styled.div`
    height: 12px;
  `
);
