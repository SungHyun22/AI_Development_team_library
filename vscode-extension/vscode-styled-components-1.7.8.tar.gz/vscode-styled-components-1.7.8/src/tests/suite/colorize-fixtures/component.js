const Component = styled(Component)`
  color: #ebebeb;
`;
