const Component = styled (Component)`
  max-width: 100%;
`;
