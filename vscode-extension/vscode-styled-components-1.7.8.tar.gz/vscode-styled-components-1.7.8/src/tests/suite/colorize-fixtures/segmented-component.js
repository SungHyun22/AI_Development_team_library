const SegmentedComponent = styled(Segmented.Component)`
  padding: 3px;
`;
