const GlobalStyles = createGlobalStyle`
  html {
    color: 'red';
  }
`;
