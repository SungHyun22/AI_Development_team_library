const Root = styled.div<RootProps>`
  height: ${props => (props.label ? 72 : 48)}px;
`;