const DotTag = styled.div`
  color: #ebebeb;
  font-size: ${props => props.theme.fontSize};
  font-family: Helvetica;
  ${mixin};
`;
