const Root = styled<RootProps>("div")`
  height: ${props => (props.label ? 72 : 48)}px;
`;