declare module '*.css' {
  let content: string
  export default content
}
