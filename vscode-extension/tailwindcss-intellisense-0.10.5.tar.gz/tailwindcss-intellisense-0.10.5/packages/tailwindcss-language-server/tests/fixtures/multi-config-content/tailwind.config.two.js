module.exports = {
  content: ['./two/**/*'],
  theme: {
    extend: {
      colors: {
        foo: 'blue',
      },
    },
  },
}
