module.exports = {
  theme: {
    extend: {
      colors: {
        foo: 'red',
      },
    },
  },
}
