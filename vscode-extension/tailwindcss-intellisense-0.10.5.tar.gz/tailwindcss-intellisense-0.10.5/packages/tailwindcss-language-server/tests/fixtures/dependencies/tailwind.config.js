const colors = require('./sub-dir/colors')

module.exports = {
  theme: {
    extend: {
      colors,
    },
  },
}
