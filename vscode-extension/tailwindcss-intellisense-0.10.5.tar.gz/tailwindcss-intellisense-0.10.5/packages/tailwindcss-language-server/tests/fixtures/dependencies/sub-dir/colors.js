module.exports = {
  foo: 'red',
}
