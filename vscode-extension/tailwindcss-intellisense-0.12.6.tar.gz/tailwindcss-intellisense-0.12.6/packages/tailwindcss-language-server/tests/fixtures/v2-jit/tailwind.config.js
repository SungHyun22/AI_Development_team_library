module.exports = {
  mode: 'jit',
}
