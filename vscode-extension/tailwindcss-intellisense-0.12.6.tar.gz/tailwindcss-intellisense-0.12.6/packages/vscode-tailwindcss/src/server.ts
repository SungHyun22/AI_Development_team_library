import '@tailwindcss/language-server/src/server'
