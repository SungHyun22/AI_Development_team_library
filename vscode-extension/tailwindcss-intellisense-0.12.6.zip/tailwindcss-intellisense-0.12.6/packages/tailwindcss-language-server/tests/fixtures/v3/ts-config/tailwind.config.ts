export default {
  theme: {
    colors: { cool: 'blue' },
  },
} satisfies {
  theme: Record<string, any>
}
