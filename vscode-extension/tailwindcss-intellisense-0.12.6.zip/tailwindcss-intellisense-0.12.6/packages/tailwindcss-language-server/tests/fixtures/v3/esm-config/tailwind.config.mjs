export default {
  theme: {
    colors: { cool: 'blue' },
  },
}
