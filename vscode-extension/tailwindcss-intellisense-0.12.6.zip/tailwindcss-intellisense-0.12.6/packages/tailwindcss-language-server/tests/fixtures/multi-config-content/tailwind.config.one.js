module.exports = {
  content: ['./one/**/*'],
  theme: {
    extend: {
      colors: {
        foo: 'red',
      },
    },
  },
}
